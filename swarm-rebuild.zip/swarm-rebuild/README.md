# Swarm Rebuild

A native, framework-independent engine that rebuilds any page from scratch with a swarm of animated cursors, then hands over to the live site. TypeScript, Canvas 2D, Web Audio, Vite. Zero runtime dependencies.

## Install & run
```bash
npm install
npm run dev          # demo at http://localhost:5173
npm run build        # demo build -> dist/
npm run build:lib    # ES + UMD library -> dist-lib/
```

## Use
```ts
import { SwarmRebuild } from 'swarm-rebuild';
const swarm = new SwarmRebuild({ selector: 'body', agents: 80, speed: 1, sound: false, autoStart: true });
swarm.replay(); swarm.finish(); swarm.destroy();
```
React: `examples/react.tsx`. Next.js (client component, dynamic import so it never runs on the server): `examples/next.tsx`.

## Options
| Option | Default | Notes |
|---|---|---|
| selector | `body` | Subtree to scan |
| agents | 80 | Capped at 28 below 700px wide |
| speed | 1 | 1–3 via panel; any 0.25–4 via `setSpeed()` |
| sound | false | Synthesized ticks; browsers need a first user gesture |
| autoStart | true | Skipped under `prefers-reduced-motion` (Replay still works) |
| tour | false | Cinematic: 0.7× pace, camera glides back to the top before going live |
| controls | true | Replay, Go live, 1×/2×/3×, Tour, Sound |

Keys: **Esc** go live, **M** sound. Methods: `start, replay, finish, destroy, setSpeed, toggleSound`.

## What you see
The whole page is scanned once. A slow follow-camera scrolls the page under the overlay as the swarm works down it (the real page scrolls in sync, so the reveal is seamless). Boxes trace then paint in, text shows a skeleton then is typed with a font tag and line guides, images go placeholder, mosaic, sharp, and repeated cards are built once then copy-pasted, with only their unique content filled in.

## Architecture
`DOMScanner` reads visible boxes, media and per-word text rects. `BlueprintGenerator` orders them top-down and sets effort. `AgentCoordinator` assigns agents in a sliding window (several agents can share a task). `ReconstructionRenderer` draws traced borders, typed text, scan-revealed images and rulers. `SwarmEngine` runs build, flock, outro via `AnimationTimeline`. `AudioController` and `UIController` are optional.

## Performance
Finished steps are cached on an offscreen layer; only in-flight steps redraw. DPR is capped at 2, there is one rAF loop paused when the tab is hidden, trails are fixed ring buffers, and agent counts drop on mobile. The live site is never modified (only `overflow` on `<html>` while running) and becomes interactive as the overlay starts fading.

## Limits
Scan covers up to 14 screens of page height. `object-fit` and CSS gradients are approximated, and text is redrawn from computed styles, so exotic fonts or effects may differ slightly until the reveal.
