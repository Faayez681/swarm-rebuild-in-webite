/** Tiny synthesized sound set (Web Audio). Nothing is loaded; silent until enabled. */
export class AudioController {
  private ctx?: AudioContext; private master?: GainNode; private last = 0;
  constructor(public enabled: boolean) {
    const wake = () => { if (this.ctx?.state === 'suspended') this.ctx.resume().catch(() => {}); };
    addEventListener('pointerdown', wake); addEventListener('keydown', wake);
  }
  set(on: boolean) { this.enabled = on; if (on) this.ensure(); }
  private ensure(): AudioContext | undefined {
    if (!this.ctx) { try { this.ctx = new AudioContext(); this.master = this.ctx.createGain(); this.master.gain.value = 0.6; this.master.connect(this.ctx.destination); } catch { return; } }
    if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
    return this.ctx;
  }
  private tone(f: number, dur: number, type: OscillatorType, g: number, to?: number) {
    const c = this.ensure(); if (!c || !this.master) return;
    const o = c.createOscillator(), v = c.createGain(), t = c.currentTime;
    o.type = type; o.frequency.setValueAtTime(f, t); if (to) o.frequency.exponentialRampToValueAtTime(to, t + dur);
    v.gain.setValueAtTime(0.0001, t); v.gain.exponentialRampToValueAtTime(g, t + 0.01); v.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(v); v.connect(this.master); o.start(t); o.stop(t + dur + 0.02);
  }
  tick() { const n = performance.now(); if (!this.enabled || n - this.last < 60) return; this.last = n; this.tone(1500 + Math.random() * 500, 0.03, 'triangle', 0.02); }
  done() { if (this.enabled) this.tone(520 + Math.random() * 120, 0.14, 'sine', 0.03, 780); }
  whoosh() { if (this.enabled) this.tone(180, 1.6, 'sine', 0.04, 720); }
}
