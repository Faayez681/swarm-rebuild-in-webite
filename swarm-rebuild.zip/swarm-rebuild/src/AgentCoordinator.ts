import { CursorAgent } from './CursorAgent';
import type { Step } from './types';
const NAMES = 'ada kay mo iris juno sol bea cy dex eli fay gus hal ivy jax kit lou max nia oz pia quin rex sky tam uma val wes xia yan zed'.split(' ');
const ease = (t: number) => t * t * (3 - 2 * t);
const cap = (s: Step) => s.dupOf ? 2 : s.kind === 'box' ? 4 : s.kind === 'image' ? 3 : s.total > 80 ? 2 : 1;
type R = { x: number; y: number; w: number; h: number };
function perim(r: R, q: number) {
  let d = (q % 1 + 1) % 1 * 2 * (r.w + r.h);
  if (d < r.w) return { x: r.x + d, y: r.y }; d -= r.w;
  if (d < r.h) return { x: r.x + r.w, y: r.y + d }; d -= r.h;
  if (d < r.w) return { x: r.x + r.w - d, y: r.y + r.h }; d -= r.w;
  return { x: r.x, y: r.y + r.h - d };
}
export interface Hooks { type(): void; done(kind: string): void }

/** Assigns agents to steps in a sliding window so the page builds progressively, in parallel. */
export class AgentCoordinator {
  agents: CursorAgent[] = []; steps: Step[] = []; first = 0; win = 10; vw = 0; vh = 0; cam = 0; focusY = 0;
  constructor(private hooks: Hooks) {}
  init(n: number, vw: number, vh: number) {
    this.vw = vw; this.vh = vh; this.cam = 0; this.agents = [];
    for (let i = 0; i < n; i++) {
      const side = i % 4, u = Math.random();
      const x = side === 0 ? u * vw : side === 1 ? vw + 40 : side === 2 ? u * vw : -40, y = side === 0 ? -40 : side === 1 ? u * vh : side === 2 ? vh + 40 : u * vh;
      this.agents.push(new CursorAgent(i, `hsl(${(i * 137.5) % 360} 80% 66%)`, NAMES[i % NAMES.length] + (i >= NAMES.length ? Math.floor(i / NAMES.length) : ''), x, y));
    }
  }
  load(steps: Step[]) {
    this.steps = steps; this.first = 0; this.agents.forEach(a => (a.task = null));
    const n = this.agents.length; this.win = Math.min(Math.max(6, Math.round(n * 0.16) + Math.floor(steps.length / 40)), Math.max(6, Math.round(n * 0.5)));
  }
  /** A duplicate can be pasted only once its original (and everything inside it) is finished. */
  private ready(s: Step) { const m = s.dupOf; return !m || (m.p >= 1 && m.kids.every(k => k.p >= 1)); }
  private point(s: Step, a: CursorAgent): { x: number; y: number } {
    const p = s.p;
    if (s.dupOf) {
      const m = s.dupOf;
      if (p < 0.35) return perim(m, p / 0.35 + a.slot * 0.5);
      const t = p < 0.85 ? ease((p - 0.35) / 0.5) : 1, ox = a.slot ? m.w : 0, oy = a.slot ? m.h : 0;
      return { x: m.x + (s.x - m.x) * t + ox, y: m.y + (s.y - m.y) * t + oy };
    }
    if (s.kind === 'box') return p < 0.5 ? perim(s, p / 0.5 + a.slot * 0.27) : { x: s.x + s.w * ((p - 0.5) / 0.5), y: s.y + s.h * (0.3 + 0.4 * Math.sin(a.slot * 2 + p * 9)) };
    if (s.kind === 'image') return p < 0.3 ? perim(s, p / 0.3 + a.slot * 0.4) : { x: s.x + s.w * (0.5 + 0.45 * Math.sin(p * 14 + a.slot * 2)), y: s.y + s.h * ((p - 0.3) / 0.7) };
    const c = Math.min(s.total - 1, Math.floor(p * s.total));
    let l = s.lines[s.lines.length - 1];
    for (const L of s.lines) if (c < L.start + L.n) { l = L; break; }
    if (a.slot > 0) return { x: l.words[0].x - 10, y: l.y + l.h + 8 + a.slot * 10 };
    let k = c - l.start;
    for (const w of l.words) { if (k <= w.t.length) return { x: w.x + w.w * k / w.t.length, y: l.y + l.h * 0.6 }; k -= w.t.length; }
    const w = l.words[l.words.length - 1]; return { x: w.x + w.w, y: l.y + l.h * 0.6 };
  }
  private drop(s: Step) {
    for (const k of s.kids) { k.hold = false; if (k.kind === 'box') k.p = 1; else if (k.kind === 'image') k.p = Math.max(k.p, 0.3); else k.ghost = true; }
    this.hooks.done('dup');
  }
  /** Advance the build. Returns true when every step is complete. */
  step(dt: number, t: number): boolean {
    const S = this.steps; while (this.first < S.length && S[this.first].p >= 1) this.first++;
    if (this.first >= S.length) { this.agents.forEach(a => { a.task = null; a.working = false; }); return true; }
    const cand: Step[] = [];
    for (let i = this.first; i < S.length && cand.length < this.win; i++) { const s = S[i]; if (s.p < 1 && !s.hold && this.ready(s) && (!cand.length || s.y <= this.cam + this.vh * 0.92)) cand.push(s); }
    this.focusY = (cand[0] || S[this.first]).y;
    if (!cand.length && !this.agents.some(a => a.task)) { S.forEach(s => { s.hold = false; s.dupOf = null; }); return false; } // watchdog
    for (const a of this.agents) { const k = a.task; if (k && (k.p >= 1 || k.hold || !this.ready(k))) a.task = null; }
    const act = new Set<Step>(cand); for (const a of this.agents) if (a.task) act.add(a.task);
    for (const s of act) { s.owners = 0; s.arr = 0; }
    for (const a of this.agents) if (a.task) a.slot = a.task.owners++;
    for (const a of this.agents) {
      if (a.task) continue;
      let best: Step | null = null, bs = 1e9;
      cand.forEach((s, i) => { const sc = Math.hypot(a.x - s.x, a.y - s.y) + s.owners * (s.owners >= cap(s) ? 1e4 : 220) + i * 12; if (sc < bs) { bs = sc; best = s; } });
      if (best) { const b = best as Step; a.task = b; a.slot = b.owners++; }
    }
    const f = cand[0] || S[this.first];
    for (const a of this.agents) {
      const s = a.task; a.working = false;
      if (s) {
        const p = this.point(s, a); a.update(dt, p.x + Math.sin(t * 13 + a.ph) * 1.5, p.y + Math.cos(t * 11 + a.ph) * 1.5, t);
        if (Math.hypot(p.x - a.x, p.y - a.y) < 44) { a.working = true; s.arr++; }
      } else a.update(dt, f.x + f.w / 2 + Math.cos(t * 0.5 + a.ph) * (60 + (a.id % 7) * 14), f.y + f.h / 2 + Math.sin(t * 0.6 + a.ph) * (40 + (a.id % 5) * 10), t);
    }
    for (const s of act) {
      if (!s.arr) continue;
      const before = s.p; s.p = Math.min(1, s.p + dt / s.work * Math.pow(s.arr, 0.8));
      if (s.kind === 'text') { const c = Math.floor(s.p * s.total); if (c > s.shown) { s.shown = c; this.hooks.type(); } }
      if (s.dupOf && before < 0.85 && s.p >= 0.85) this.drop(s);
      if (s.p >= 1 && before < 1) this.hooks.done(s.kind);
    }
    return false;
  }
  finishAll() { this.steps.forEach(s => { s.p = 1; s.hold = false; }); }
  /** Flock: agents gather around a moving leader, then dash off (u > 1). */
  flock(dt: number, t: number, u: number) {
    const cx = this.vw / 2, cy = this.cam + this.vh / 2; let lx: number, ly: number, spread: number, spd = 1;
    if (u < 1) {
      spread = 1 - 0.72 * ease(Math.min(1, u * 1.6)); const m = Math.max(0, (u - 0.35) / 0.65);
      lx = cx + Math.sin(m * Math.PI * 1.5) * this.vw * 0.24 * m; ly = cy + Math.sin(m * Math.PI * 3) * this.vh * 0.12 * m;
    } else { const k = u - 1; spread = 0.28; spd = 2.5; lx = cx + k * k * this.vw * 1.6; ly = cy - k * k * this.vh * 1.1; }
    for (const a of this.agents) {
      const ang = a.id * 2.39996 + t * 0.35, rad = (14 + Math.sqrt(a.id + 1) * 11) * (0.4 + spread * 1.6);
      a.update(dt, lx + Math.cos(ang) * rad, ly + Math.sin(ang) * rad * 0.7, t, spd);
    }
    const A = this.agents;
    for (let i = 0; i < A.length; i++) for (let j = i + 1; j < A.length; j++) {
      const dx = A[j].x - A[i].x, dy = A[j].y - A[i].y, d = Math.hypot(dx, dy);
      if (d > 0 && d < 13) { const k = (13 - d) * 0.5 / d; A[i].x -= dx * k; A[i].y -= dy * k; A[j].x += dx * k; A[j].y += dy * k; }
    }
  }
}
