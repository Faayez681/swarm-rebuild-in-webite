export interface SwarmOptions { selector?: string; agents?: number; speed?: number; sound?: boolean; autoStart?: boolean; tour?: boolean; controls?: boolean }
export interface Word { t: string; x: number; w: number }
export interface Line { y: number; h: number; words: Word[]; start: number; n: number }
export type Kind = 'box' | 'text' | 'image';
export interface Step {
  kind: Kind; x: number; y: number; w: number; h: number; r: number; bg: string | null; bc: string | null; bw: number;
  color: string; font: string; ls: string; lines: Line[]; total: number; img: CanvasImageSource | null; tint: string;
  work: number; p: number; owners: number; arr: number; shown: number;
  fs: number; fam: string; hold: boolean; fixed: boolean; ghost: boolean; dupOf: Step | null; kids: Step[];
}
export interface Blueprint { steps: Step[]; bg: string; dark: boolean }
export type Phase = 'idle' | 'build' | 'flock' | 'outro' | 'done';
