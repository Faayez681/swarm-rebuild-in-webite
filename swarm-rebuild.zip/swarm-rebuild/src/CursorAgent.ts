import type { Step } from './types';
export const TRAIL = 16;
export class CursorAgent {
  x: number; y: number; vx = 0; vy = 0; task: Step | null = null; slot = 0; working = false;
  readonly max = 520 + Math.random() * 520; readonly acc = 2200 + Math.random() * 1800;
  readonly ph = Math.random() * 6.28; readonly curve = (Math.random() < 0.5 ? -1 : 1) * (0.5 + Math.random());
  readonly trail = new Float32Array(TRAIL * 2); th = 0; tn = 0;
  constructor(public id: number, public color: string, public name: string, x: number, y: number) { this.x = x; this.y = y; }
  /** Steer toward (tx,ty): eased arrival, accel-limited turning, gentle curved approach. */
  update(dt: number, tx: number, ty: number, t: number, spd = 1) {
    const dx = tx - this.x, dy = ty - this.y, d = Math.hypot(dx, dy) || 1;
    const sp = Math.min(this.max * spd, d * 5.5);
    const bend = Math.min(1, d / 400) * this.curve * Math.sin(t * 0.8 + this.ph) * 0.35;
    let ax = dx / d * sp - dy / d * sp * bend - this.vx, ay = dy / d * sp + dx / d * sp * bend - this.vy;
    const am = Math.hypot(ax, ay), lim = this.acc * spd * dt;
    if (am > lim) { ax *= lim / am; ay *= lim / am; }
    this.vx += ax; this.vy += ay; this.x += this.vx * dt; this.y += this.vy * dt;
    this.trail[this.th * 2] = this.x; this.trail[this.th * 2 + 1] = this.y;
    this.th = (this.th + 1) % TRAIL; this.tn = Math.min(TRAIL, this.tn + 1);
  }
}
