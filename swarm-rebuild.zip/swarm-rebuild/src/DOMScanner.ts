import type { Kind, Line, Step } from './types';
const SKIP = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'LINK', 'META', 'TEMPLATE', 'HEAD']);
const MEDIA = new Set(['IMG', 'VIDEO', 'CANVAS', 'SVG', 'PICTURE']);
const clear = (c: string) => !c || c === 'transparent' || /rgba\(.*,\s*0\)$/.test(c);

function average(img: HTMLImageElement, fb: string): string {
  try {
    const c = document.createElement('canvas'); c.width = c.height = 1;
    const x = c.getContext('2d')!; x.drawImage(img, 0, 0, 1, 1);
    const d = x.getImageData(0, 0, 1, 1).data; return `rgb(${d[0]},${d[1]},${d[2]})`;
  } catch { return fb; }
}

/** Reads the live DOM into raw construction steps in document coordinates. Call with the page scrolled to the top. */
export class DOMScanner {
  private out: Step[] = []; private imgs = 0;
  constructor(private root: Element, private maxY: number, private max = 1200) {}
  scan(): Step[] { this.out = []; this.imgs = 0; this.walk(this.root, false); return this.out; }
  pageBg(): string {
    let e: Element | null = this.root;
    while (e) { const c = getComputedStyle(e).backgroundColor; if (!clear(c)) return c; e = e.parentElement; }
    return 'rgb(255,255,255)';
  }
  private walk(el: Element, fx: boolean) {
    const tag = el.tagName.toUpperCase();
    if (this.out.length >= this.max || SKIP.has(tag) || el.hasAttribute('data-swarm')) return;
    const cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden' || +cs.opacity < 0.05) return;
    const r = el.getBoundingClientRect(), vw = document.documentElement.clientWidth;
    if (r.bottom < 0 || r.top > this.maxY || r.right < 0 || r.left > vw) return;
    const isFx = fx || cs.position === 'fixed' || (cs.position === 'sticky' && r.top <= (parseFloat(cs.top) || 0) + 2);
    if (MEDIA.has(tag)) { if (r.width >= 4 && r.height >= 4) this.add('image', r, cs, el, isFx); return; }
    const big = r.width >= vw * 0.98 && r.height >= innerHeight * 0.9;
    if (r.width >= 2 && r.height >= 2 && !big && tag !== 'BODY' && tag !== 'HTML') {
      const bw = cs.borderTopStyle === 'none' ? 0 : parseFloat(cs.borderTopWidth) || 0;
      const bg = clear(cs.backgroundColor) ? (cs.backgroundImage !== 'none' ? 'rgba(127,127,127,.12)' : null) : cs.backgroundColor;
      if (bg || bw > 0) this.add('box', r, cs, el, isFx, bg, bw);
    }
    for (const n of Array.from(el.childNodes)) {
      if (n.nodeType === 1) this.walk(n as Element, isFx);
      else if (n.nodeType === 3) this.text(n as Text, cs, isFx);
    }
  }
  private add(kind: Kind, r: DOMRect, cs: CSSStyleDeclaration, el: Element, fixed: boolean, bg: string | null = null, bw = 0) {
    let img: CanvasImageSource | null = null, tint = 'rgba(127,127,127,.25)';
    if (kind === 'image') {
      if (el instanceof HTMLImageElement && el.complete && el.naturalWidth) { img = el; if (this.imgs++ < 30) tint = average(el, tint); }
      else if (el instanceof HTMLVideoElement && el.readyState > 1) img = el;
    }
    const rs = cs.borderTopLeftRadius; let rad = parseFloat(rs) || 0;
    if (rs.includes('%')) rad = Math.min(r.width, r.height) * rad / 100;
    this.out.push({ kind, x: r.left, y: r.top, w: r.width, h: r.height, r: Math.min(rad, r.width / 2, r.height / 2), bg, bc: bw > 0 ? cs.borderTopColor : null, bw,
      color: '', font: '', ls: '', lines: [], total: 0, img, tint, work: 0, p: 0, owners: 0, arr: 0, shown: 0, fs: 0, fam: '', hold: false, fixed, ghost: false, dupOf: null, kids: [] });
  }
  private text(n: Text, cs: CSSStyleDeclaration, fixed: boolean) {
    const s = n.textContent || ''; if (!s.trim() || this.out.length >= this.max) return;
    const rg = document.createRange(), re = /\S+/g, lines: Line[] = [];
    const up = cs.textTransform === 'uppercase', lo = cs.textTransform === 'lowercase';
    let m: RegExpExecArray | null, cur: Line | null = null, total = 0;
    while ((m = re.exec(s))) {
      rg.setStart(n, m.index); rg.setEnd(n, m.index + m[0].length);
      const b = rg.getBoundingClientRect(); if (b.width < 1 || b.bottom < 0 || b.top > this.maxY) continue;
      if (!cur || Math.abs(b.top - cur.y) > b.height * 0.5) { cur = { y: b.top, h: b.height, words: [], start: total, n: 0 }; lines.push(cur); }
      const t = up ? m[0].toUpperCase() : lo ? m[0].toLowerCase() : m[0];
      cur.words.push({ t, x: b.left, w: b.width }); cur.n += t.length; total += t.length;
    }
    if (!total) return;
    const x = Math.min(...lines.map(l => l.words[0].x)), last = lines[lines.length - 1];
    const right = Math.max(...lines.map(l => { const w = l.words[l.words.length - 1]; return w.x + w.w; }));
    this.out.push({ kind: 'text', x, y: lines[0].y, w: right - x, h: last.y + last.h - lines[0].y, r: 0, bg: null, bc: null, bw: 0,
      color: cs.color, font: `${cs.fontStyle} ${cs.fontWeight} ${cs.fontSize} ${cs.fontFamily}`, ls: cs.letterSpacing === 'normal' ? '0px' : cs.letterSpacing,
      lines, total, img: null, tint: '', work: 0, p: 0, owners: 0, arr: 0, shown: 0,
      fs: parseFloat(cs.fontSize) || 16, fam: `${cs.fontFamily.split(',')[0].replace(/["']/g, '').trim()} ${cs.fontWeight}`, hold: false, fixed, ghost: false, dupOf: null, kids: [] });
  }
}
