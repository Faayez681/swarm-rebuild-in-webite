import type { Blueprint, Step } from './types';
import type { CursorAgent } from './CursorAgent';
import { TRAIL } from './CursorAgent';
type Ctx = CanvasRenderingContext2D;
const clamp = (v: number) => Math.max(0, Math.min(1, v));
const ease = (t: number) => t * t * (3 - 2 * t);
function path(c: Ctx, x: number, y: number, w: number, h: number, r: number) {
  r = Math.max(0, Math.min(r, w / 2, h / 2)); c.beginPath(); c.moveTo(x + r, y);
  c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath();
}
const accent = (dark: boolean) => (dark ? '150,185,255' : '40,80,220');

let sm: HTMLCanvasElement | null = null;
/** Mosaic draw: image sampled down to a coarse grid and scaled up without smoothing. */
function pix(c: Ctx, img: CanvasImageSource, x: number, y: number, w: number, h: number, ps: number) {
  const t = sm || (sm = document.createElement('canvas')), sw = Math.max(1, Math.ceil(w / ps)), sh = Math.max(1, Math.ceil(h / ps));
  t.width = sw; t.height = sh; const tc = t.getContext('2d')!;
  try { tc.drawImage(img, 0, 0, sw, sh); } catch { return; }
  const o = c.imageSmoothingEnabled; c.imageSmoothingEnabled = false; c.drawImage(t, 0, 0, sw, sh, x, y, sw * ps, sh * ps); c.imageSmoothingEnabled = o;
}

/** Draws one step at its current progress (1 = final state). */
function drawStep(c: Ctx, s: Step, dark: boolean) {
  if (s.hold) return;
  let p = s.p; if (s.dupOf) { if (p < 0.85) return; p = 1; }
  const A = accent(dark), per = 2 * (s.w + s.h), g0 = c.globalAlpha;
  if (s.kind === 'box') {
    const t = clamp(p / 0.5), f = clamp((p - 0.5) / 0.5);
    if (s.bg && f > 0) { // paint wipe, left to right
      c.save(); path(c, s.x, s.y, s.w, s.h, s.r); c.clip(); c.fillStyle = s.bg; c.fillRect(s.x, s.y, s.w * f + (f >= 1 ? 1 : 0), s.h);
      if (f < 1) { c.fillStyle = `rgba(${A},.7)`; c.fillRect(s.x + s.w * f, s.y, 1.5, s.h); }
      c.restore();
    }
    if (s.bc || p < 1) {
      const hw = s.bw / 2; c.lineWidth = s.bc ? s.bw : 1; c.strokeStyle = s.bc || `rgba(${A},${0.55 * (1 - f)})`;
      path(c, s.x + hw, s.y + hw, s.w - s.bw, s.h - s.bw, s.r); c.setLineDash(t < 1 ? [per * t, per] : []); c.stroke(); c.setLineDash([]);
    }
  } else if (s.kind === 'text') {
    let left = p >= 1 ? s.total : Math.floor(p * s.total);
    c.font = s.font; c.fillStyle = s.color; c.strokeStyle = s.color; c.lineWidth = 1; c.textBaseline = 'middle'; (c as any).letterSpacing = s.ls;
    for (const l of s.lines) {
      const mid = l.y + l.h / 2;
      for (const w of l.words) {
        if (left >= w.t.length) { c.fillText(w.t, w.x, mid); left -= w.t.length; continue; }
        let x0 = w.x;
        if (left > 0) { // word in progress: fresh glyphs are inked as outlines first
          const pre = w.t.slice(0, Math.max(0, left - 2)), ink = w.t.slice(Math.max(0, left - 2), left);
          c.fillText(pre, w.x, mid); const px = w.x + c.measureText(pre).width; c.strokeText(ink, px, mid);
          x0 = px + c.measureText(ink).width; c.globalAlpha = g0 * 0.9; c.fillRect(x0 + 1, l.y + l.h * 0.1, 1.5, l.h * 0.8); c.globalAlpha = g0; left = 0;
        }
        if (p < 1) { c.globalAlpha = g0 * 0.13; path(c, x0, mid - s.fs * 0.3, Math.max(2, w.x + w.w - x0), s.fs * 0.6, s.fs * 0.15); c.fill(); c.globalAlpha = g0; }
      }
    }
    (c as any).letterSpacing = '0px';
  } else {
    const a = clamp(p / 0.3), f = clamp((p - 0.3) / 0.7);
    c.save(); path(c, s.x, s.y, s.w, s.h, s.r);
    if (p < 1) { c.save(); c.strokeStyle = `rgba(${A},${0.55 * (1 - f)})`; c.lineWidth = 1; c.setLineDash(a < 1 ? [per * a, per] : []); c.stroke(); c.restore(); }
    if (f <= 0) { // placeholder: crossed frame
      c.strokeStyle = `rgba(${A},${0.3 * a})`; c.lineWidth = 1; c.beginPath();
      c.moveTo(s.x, s.y); c.lineTo(s.x + s.w * a, s.y + s.h * a); c.moveTo(s.x + s.w, s.y); c.lineTo(s.x + s.w - s.w * a, s.y + s.h * a); c.stroke();
    } else {
      c.clip(); c.fillStyle = s.tint; c.globalAlpha = g0 * 0.35; c.fillRect(s.x, s.y, s.w, s.h); c.globalAlpha = g0;
      if (s.img && f >= 1) { try { c.drawImage(s.img, s.x, s.y, s.w, s.h); } catch { /* unreadable */ } }
      else if (s.img) { // mosaic everywhere, sharpening top-down behind the scan line
        const hh = Math.floor(s.h * f / 4) * 4; pix(c, s.img, s.x, s.y, s.w, s.h, 24);
        c.save(); c.beginPath(); c.rect(s.x, s.y, s.w, hh); c.clip(); pix(c, s.img, s.x, s.y, s.w, s.h, Math.max(1, Math.round(10 * (1 - f)))); c.restore();
        c.fillStyle = `rgba(${A},.8)`; c.fillRect(s.x, s.y + hh, s.w, 1);
      } else { c.globalAlpha = g0 * f; c.fillStyle = s.tint; c.fillRect(s.x, s.y, s.w, s.h); c.globalAlpha = g0; }
    }
    c.restore();
  }
}

/** Draws the reconstruction in document space through a scrolling camera. Only steps in view are drawn. */
export class ReconstructionRenderer {
  private ctx: Ctx; private vw = 0; private vh = 0; private bp: Blueprint = { steps: [], bg: '#fff', dark: false };
  constructor(private canvas: HTMLCanvasElement) { this.ctx = canvas.getContext('2d')!; }
  resize(vw: number, vh: number) {
    const d = Math.min(devicePixelRatio || 1, 2); this.vw = vw; this.vh = vh;
    this.canvas.width = Math.round(vw * d); this.canvas.height = Math.round(vh * d); this.ctx.setTransform(d, 0, 0, d, 0, 0);
  }
  setBlueprint(bp: Blueprint) { this.bp = bp; }
  render(cam: number, agents: CursorAgent[]) {
    const c = this.ctx, { steps, bg, dark } = this.bp, top = cam - 24, bot = cam + this.vh + 24;
    c.fillStyle = bg; c.fillRect(0, 0, this.vw, this.vh);
    c.save(); c.translate(0, -cam);
    for (const t of steps) {
      if (t.hold || t.fixed) continue;
      if (t.dupOf && t.p > 0 && t.p < 1) this.dup(c, t, dark);
      if (t.y > bot || t.y + t.h < top) continue;
      if (t.p > 0 || t.ghost) drawStep(c, t, dark);
    }
    c.restore();
    for (const t of steps) if (t.fixed && !t.hold && (t.p > 0 || t.ghost)) drawStep(c, t, dark);
    c.save(); c.translate(0, -cam); this.guides(c, cam, dark); this.agents(c, agents, dark); c.restore();
  }
  private marquee(c: Ctx, x: number, y: number, w: number, h: number, a: number, label: string, dark: boolean) {
    const A = accent(dark); c.save(); c.strokeStyle = `rgba(${A},${a})`; c.fillStyle = `rgba(${A},${a})`; c.lineWidth = 1; c.setLineDash([5, 4]);
    c.strokeRect(x - 3.5, y - 3.5, w + 7, h + 7); c.setLineDash([]);
    for (const [px, py] of [[x, y], [x + w / 2, y], [x + w, y], [x, y + h / 2], [x + w, y + h / 2], [x, y + h], [x + w / 2, y + h], [x + w, y + h]]) c.fillRect(px - 3, py - 3, 6, 6);
    c.font = '10px ui-monospace,Menlo,monospace'; c.textBaseline = 'alphabetic'; c.fillText(label, x, y - 9); c.restore();
  }
  /** Copy/paste of a finished component: select it, lift a ghost copy, drop it in place. */
  private dup(c: Ctx, s: Step, dark: boolean) {
    const m = s.dupOf!, p = s.p;
    if (p < 0.35) { this.marquee(c, m.x, m.y, m.w, m.h, clamp(p / 0.08) * 0.8, 'copy', dark); return; }
    const t = p < 0.85 ? ease((p - 0.35) / 0.5) : 1, dx = (s.x - m.x) * t, dy = (s.y - m.y) * t;
    c.save(); c.globalAlpha = p < 0.85 ? 0.55 : 0.55 * (1 - (p - 0.85) / 0.15); c.translate(dx, dy);
    for (const st of [m, ...m.kids]) drawStep(c, st, dark);
    c.restore();
    if (p < 0.85) this.marquee(c, m.x + dx, m.y + dy, m.w, m.h, 0.7, 'paste', dark);
  }
  /** Temporary rulers: font line boxes while typing, crosshair guides + dimensions while boxes and images are built. */
  private guides(c: Ctx, cam: number, dark: boolean) {
    const A = accent(dark), S = this.bp.steps, lo = cam - 40, hi = cam + this.vh + 40; let n = 0, tn = 0;
    c.textBaseline = 'alphabetic';
    for (const s of S) {
      if (s.hold || s.p <= 0 || s.p >= 1 || s.y > hi || s.y + s.h < lo || s.fixed) continue;
      if (s.kind === 'text') {
        if (tn++ >= 2) continue;
        const ch = Math.floor(s.p * s.total); let l = s.lines[s.lines.length - 1]; for (const L of s.lines) if (ch < L.start + L.n) { l = L; break; }
        c.strokeStyle = `rgba(${A},.3)`; c.lineWidth = 1; c.setLineDash([3, 3]); c.beginPath();
        for (const yy of [l.y, l.y + l.h * 0.78, l.y + l.h]) { c.moveTo(s.x - 14, yy); c.lineTo(s.x + s.w + 14, yy); }
        c.stroke(); c.setLineDash([]); c.fillStyle = `rgba(${A},.8)`; c.font = '9px ui-monospace,Menlo,monospace'; c.fillText(`${s.fam} · ${Math.round(s.fs)}px`, s.x, l.y - 4);
      } else if (s.w * s.h >= 3000 && n < 3) {
        n++;
        const a = clamp(s.p * 6) * clamp((1 - s.p) * 5) * 0.35, e = ease(clamp(s.p * 4)), r = s.x + s.w, b = s.y + s.h;
        c.strokeStyle = `rgba(${A},${a})`; c.lineWidth = 1; c.setLineDash([4, 4]); c.beginPath();
        for (const y of [s.y, b]) { c.moveTo(s.x - s.x * e, y); c.lineTo(r + (this.vw - r) * e, y); }
        for (const x of [s.x, r]) { c.moveTo(x, s.y - (s.y - cam) * e); c.lineTo(x, b + (cam + this.vh - b) * e); }
        c.stroke(); c.setLineDash([]); c.fillStyle = `rgba(${A},${a * 2})`;
        for (const [x, y] of [[s.x, s.y], [r, s.y], [r, b], [s.x, b]]) c.fillRect(x - 2, y - 2, 4, 4);
        c.font = '10px ui-monospace,Menlo,monospace'; c.fillText(`${Math.round(s.w)} × ${Math.round(s.h)}`, r + 8, b + 14);
      }
    }
  }
  private agents(c: Ctx, agents: CursorAgent[], dark: boolean) {
    c.textBaseline = 'middle'; c.lineJoin = 'round';
    for (const a of agents) {
      if (a.tn > 3) {
        c.strokeStyle = a.color; c.lineWidth = 1.4;
        for (let k = 0; k < 3; k++) {
          const i0 = Math.floor(k * a.tn / 3), i1 = Math.min(a.tn - 1, Math.floor((k + 1) * a.tn / 3));
          c.globalAlpha = 0.08 + 0.14 * k; c.beginPath();
          for (let i = i0; i <= i1; i++) { const j = (a.th - a.tn + i + TRAIL * 2) % TRAIL; i === i0 ? c.moveTo(a.trail[j * 2], a.trail[j * 2 + 1]) : c.lineTo(a.trail[j * 2], a.trail[j * 2 + 1]); }
          c.stroke();
        }
        c.globalAlpha = 1;
      }
      c.save(); c.translate(a.x, a.y); c.fillStyle = a.color; c.strokeStyle = dark ? 'rgba(255,255,255,.85)' : 'rgba(0,0,0,.6)'; c.lineWidth = 1;
      const k = a.working && a.task ? a.task.kind : null;
      if (k === 'text') { c.strokeStyle = a.color; c.lineWidth = 1.6; c.beginPath(); c.moveTo(0, -7); c.lineTo(0, 7); c.moveTo(-3, -7); c.lineTo(3, -7); c.moveTo(-3, 7); c.lineTo(3, 7); c.stroke(); }
      else {
        if (k) { c.strokeStyle = a.color; c.lineWidth = 1; c.beginPath(); c.moveTo(-7, 0); c.lineTo(7, 0); c.moveTo(0, -7); c.lineTo(0, 7); c.stroke(); c.strokeStyle = dark ? 'rgba(255,255,255,.85)' : 'rgba(0,0,0,.6)'; }
        c.beginPath(); c.moveTo(0, 0); c.lineTo(0, 15); c.lineTo(3.8, 11.6); c.lineTo(6.4, 17.4); c.lineTo(8.6, 16.4); c.lineTo(6.1, 10.7); c.lineTo(11, 10.7); c.closePath(); c.fill(); c.stroke();
      }
      const w = a.name.length * 5.4 + 10; c.globalAlpha = a.working ? 0.95 : 0.7; c.fillStyle = a.color; path(c, 10, 14, w, 13, 6.5); c.fill();
      c.globalAlpha = 1; c.fillStyle = '#0b0c10'; c.font = '600 9px system-ui,sans-serif'; c.fillText(a.name, 15, 20.8); c.restore();
    }
  }
}
